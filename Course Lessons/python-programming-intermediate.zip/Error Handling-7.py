## 2. Sets ##

# 2
gender = []
for l in legislators:
    gender.append(l[3])
gender = set(gender)
print(gender)

## 3. Exploring the Dataset ##

party = []
for l in legislators:
    party.append(l[6])

party = set(party)
print(party)
print(legislators)

## 4. Missing Values ##

for l in legislators:
    if l[3] == "":
        l[3] = "M"

## 5. Parsing Birth Years ##

birth_years = []
for l in legislators:
    parts = l[2].split("-")
    birth_years.append(parts[0])
    
print(birth_years)

## 6. Try/except Blocks ##

try:
    float("hello")
except Exception:
    print("Error converting to float.")

## 7. Exception Instances ##

try:
    int('')
except Exception as e:
    print(type(e))
    print(str(e))

## 8. The Pass Keyword ##

converted_years = []

for b in birth_years:
    year = b
    try:
        year = int(year)
    except Exception:
        pass
    converted_years.append(year)

## 9. Convert Birth Years to Integers ##

for l in legislators:
    year = l[2].split("-")[0]
    try:
        birth_year = int(year)
    except Exception:
        birth_year = 0
    l.append(birth_year)
print(legislators[:5])

## 10. Fill in Years Without a Value ##

last_value = 1
for l in legislators:
    if l[7] == 0:
        l[7] = last_value
    last_value = l[7]