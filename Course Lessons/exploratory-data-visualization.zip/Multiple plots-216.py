## 1. Recap ##

import pandas as pd
import matplotlib.pyplot as plt

unrate = pd.read_csv('unrate.csv')
unrate['DATE'] = pd.to_datetime(unrate['DATE'])

x_val = unrate[:12]["DATE"]
y_val = unrate[:12]["VALUE"]
plt.xticks(rotation=90)
plt.xlabel("Month")
plt.ylabel("Unemployment Rate")
plt.title("Monthly Unemployment Trends, 1948")

plt.plot(x_val, y_val)
plt.show()


## 3. Matplotlib Classes ##

import matplotlib.pyplot as plt

fig = plt.figure()
ax1 = fig.add_subplot(2,1,1)
ax2 = fig.add_subplot(2,1,2)

plt.show()

## 5. Adding Data ##

import matplotlib.pyplot as plt

x_val_1948 = unrate[:12]["DATE"]
y_val_1948 = unrate[:12]["VALUE"]
x_val_1949 = unrate[12:24]["DATE"]
y_val_1949 = unrate[12:24]["VALUE"]

fig = plt.figure()
ax1 = fig.add_subplot(2, 1, 1)
ax2 = fig.add_subplot(2, 1, 2)

ax1.plot(x_val_1948, y_val_1948)
ax2.plot(x_val_1949, y_val_1949)

plt.show()

## 6. Formatting And Spacing ##

fig = plt.figure(figsize=(12,5))
ax1 = fig.add_subplot(2,1,1)
ax2 = fig.add_subplot(2,1,2)
ax1.plot(unrate[0:12]['DATE'], unrate[0:12]['VALUE'])
ax1.set_title('Monthly Unemployment Rate, 1948')
ax2.plot(unrate[12:24]['DATE'], unrate[12:24]['VALUE'])
ax2.set_title('Monthly Unemployment Rate, 1949')
plt.show()

## 7. Comparing Across More Years ##

fig = plt.figure(figsize=(12, 12))
for i in range(5):
    x_val = unrate[i * 12: (i + 1) * 12]["DATE"]
    y_val = unrate[i * 12: (i + 1) * 12]["VALUE"]

    ax = fig.add_subplot(5, 1, i + 1)
    ax.plot(x_val, y_val)

plt.show()

## 8. Overlaying Line Charts ##

unrate['MONTH'] = unrate['DATE'].dt.month

fig = plt.figure(figsize=(6,3))

x_val = unrate[0:12]["MONTH"]
y_val = unrate[0:12]["VALUE"]
plt.plot(x_val, y_val, c="red")
x_val = unrate[12:24]["MONTH"]
y_val = unrate[12:24]["VALUE"]
plt.plot(x_val, y_val, c="blue")

plt.show()

## 9. Adding More Lines ##

fig = plt.figure(figsize=(10, 6))
colors = ["red", "blue", "green", "orange", "black"]

for i in range(5):
    plt.plot(unrate[i * 12: (i + 1) * 12]["MONTH"], unrate[i * 12: (i + 1) * 12]["VALUE"], c=colors[i])

plt.show()

## 10. Adding A Legend ##

fig = plt.figure(figsize=(10, 6))
colors = ["red", "blue", "green", "orange", "black"]

for i in range(5):
    plt.plot(unrate[i * 12:(i + 1) * 12]["MONTH"], unrate[i * 12:(i + 1) * 12]["VALUE"], c=colors[i],
             label=str(1948 + i))

plt.legend(loc="upper left")
plt.show()

## 11. Final Tweaks ##

fig = plt.figure(figsize=(10, 6))
colors = ["red", "blue", "green", "orange", "black"]

for i in range(5):
    plt.plot(unrate[i * 12:(i + 1) * 12]["MONTH"], unrate[i * 12:(i + 1) * 12]["VALUE"], c=colors[i],
             label=str(1948 + i))

plt.legend(loc="upper left")
plt.title("Monthly Unemployment Trends, 1948-1952")
plt.xlabel("Month, Integer")
plt.ylabel("Unemployment Rate, Percent")
plt.show()