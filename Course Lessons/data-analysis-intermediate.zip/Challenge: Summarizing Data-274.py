## 2. Introduction to the Data ##

import pandas as pd
all_ages = pd.read_csv("all-ages.csv")
recent_grads = pd.read_csv("recent-grads.csv")

print(all_ages.iloc[:5])
print(recent_grads.iloc[:5])

## 3. Summarizing Major Categories ##

# Unique values in Major_category column.
print(all_ages['Major_category'].unique())

aa_cat_counts = dict()
rg_cat_counts = dict()

for cat in all_ages['Major_category'].unique():
    cat_rows = all_ages[all_ages['Major_category'] == cat]
    aa_cat_counts[cat] = cat_rows["Total"].sum()
    
for cat in recent_grads['Major_category'].unique():
    cat_rows = recent_grads[recent_grads['Major_category'] == cat]
    rg_cat_counts[cat] = cat_rows["Total"].sum()

## 4. Low-Wage Job Rates ##

low_wage_percent = 0.0

total_jobs = recent_grads["Total"].sum()
low_wage_jobs = recent_grads["Low_wage_jobs"].sum()
low_wage_proportion = low_wage_jobs / total_jobs
print(low_wage_proportion)

## 5. Comparing Data Sets ##

# All majors, common to both DataFrames
majors = recent_grads['Major'].unique()
rg_lower_count = 0

for major in majors:
    aa_rows = all_ages[all_ages["Major"] == major]
    rg_rows = recent_grads[recent_grads["Major"] == major]
    if rg_rows["Unemployment_rate"].iloc[0] < aa_rows["Unemployment_rate"].iloc[0]:
        rg_lower_count += 1

print(rg_lower_count)